cdata =
{
	Extended           					= _('F-15C Use Extended Animations'),
}
