local count = 0
local function counter()
	count = count + 1
	return count
end
-------DEVICE ID-------
devices = {}
devices["CLICKABLE"]     			= counter()
devices["PNT_UPD"]     				= counter()
devices["LIGHT_CONTROL"]			= counter()
devices["RADAR_CONTROL"]			= counter()



