local  aircraft = get_aircraft_type()											--Reading the variable
if 	aircraft == "F-15C" then
	supported = true															--The mod will start
else
	supported = false															--The mod will not start
end