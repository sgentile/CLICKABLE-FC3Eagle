dofile(LockOn_Options.script_path.."dump.lua")
local  aircraft = get_aircraft_type()

if aircraft == "F-15C" then
    shape_name = "F-15C-CLICKABLE"
end



local controllers = LoRegisterPanelControls()

THROTTLE_L_PNTS						= CreateGauge("parameter")
THROTTLE_L_PNTS.arg_number			= 1
THROTTLE_L_PNTS.input				= {0,1}
THROTTLE_L_PNTS.output				= {-1,0}
THROTTLE_L_PNTS.parameter_name		= "BASE_SENSOR_LEFT_THROTTLE_POS"

THROTTLE_R_PNTS						= CreateGauge("parameter")
THROTTLE_R_PNTS.arg_number			= 2
THROTTLE_R_PNTS.input				= {0,1}
THROTTLE_R_PNTS.output				= {-1,0}
THROTTLE_R_PNTS.parameter_name		= "BASE_SENSOR_RIGHT_THROTTLE_POS"


STICK_PITCH_PNTS						= CreateGauge("parameter")
STICK_PITCH_PNTS.arg_number			= 3
STICK_PITCH_PNTS.input				= {-1,1}
STICK_PITCH_PNTS.output				= {-1,1}
STICK_PITCH_PNTS.parameter_name		= "BASE_SENSOR_STICK_PITCH_NORMED"

STICK_ROLL_PNTS						= CreateGauge("parameter")
STICK_ROLL_PNTS.arg_number			= 4
STICK_ROLL_PNTS.input				= {-1,1}
STICK_ROLL_PNTS.output				= {-1,1}
STICK_ROLL_PNTS.parameter_name		= "BASE_SENSOR_STICK_ROLL_NORMED"

CANOPY_PNTS						    = CreateGauge("parameter")
CANOPY_PNTS.arg_number			    = 5
CANOPY_PNTS.input				    = {-1,1}
CANOPY_PNTS.output				    = {-1,1}
CANOPY_PNTS.parameter_name		    = "BASE_SENSOR_CANOPY_POS"

GEARLEVER_PNTS						= CreateGauge("parameter")
GEARLEVER_PNTS.arg_number			= 6
GEARLEVER_PNTS.input				= {0,1}
GEARLEVER_PNTS.output				= {100,-100} 
GEARLEVER_PNTS.parameter_name		= "BASE_SENSOR_GEAR_HANDLE"

CANOPYLEVER_PNTS						= CreateGauge("parameter")
CANOPYLEVER_PNTS.arg_number			= 7
CANOPYLEVER_PNTS.input				= {-1,1}
CANOPYLEVER_PNTS.output				= {-1,1}
CANOPYLEVER_PNTS.parameter_name		= "CANOPYLEVER_PNTS"

if  aircraft=="F-15C"                       then
    THROTTLE_R_PNTS						= CreateGauge("parameter")
    THROTTLE_R_PNTS.arg_number			= 2
    THROTTLE_R_PNTS.input				= {-1,1}
    THROTTLE_R_PNTS.output				= {-1,1}
    THROTTLE_R_PNTS.parameter_name		= "BASE_SENSOR_RIGHT_THROTTLE_POS"

    PSI_CABIN                           = CreateGauge("parameter")
    PSI_CABIN.arg_number                = 114
    PSI_CABIN.input                     = {-1.0, 1.0}
    PSI_CABIN.output                    = {-1.0, 1.0}
    PSI_CABIN.parameter_name            = "PSI_CABIN"

    PSI_OXY                             = CreateGauge("parameter")
    PSI_OXY.arg_number                  = 363
    PSI_OXY.input                       = {-1.0, 1.0}
    PSI_OXY.output                      = {-1.0, 1.0}
    PSI_OXY.parameter_name              = "PSI_OXY"

    LIQUID_OXY                          = CreateGauge("parameter")
    LIQUID_OXY.arg_number               = 376
    LIQUID_OXY.input                    = {-1.0, 1.0}
    LIQUID_OXY.output                   = {-1.0, 1.0}
    LIQUID_OXY.parameter_name           = "LIQUID_OXY"

    -- Light Control System params
    MISC_TAXI_LIGHT                     = CreateGauge("parameter")
    MISC_TAXI_LIGHT.arg_number          = 428
    MISC_TAXI_LIGHT.input               = {-1.0, 1.0}
    MISC_TAXI_LIGHT.output              = {-1.0, 1.0}
    MISC_TAXI_LIGHT.parameter_name      = "MISC_TAXI_LIGHT"

    -- Radar Control System params
    RADAR_POWER                         = CreateGauge("parameter")
    RADAR_POWER.arg_number              = 488
    RADAR_POWER.input                   = {0, 1}
    RADAR_POWER.output                  = {0, 1}
    RADAR_POWER.parameter_name          = "RADAR_POWER"

    RADAR_MODE_SEL                      = CreateGauge("parameter")
    RADAR_MODE_SEL.arg_number           = 493
    RADAR_MODE_SEL.input                = {0, 3}
    RADAR_MODE_SEL.output               = {0, 1}
    RADAR_MODE_SEL.parameter_name       = "RADAR_MODE_SEL"

    RADAR_SPL_MODE                      = CreateGauge("parameter")
    RADAR_SPL_MODE.arg_number           = 492
    RADAR_SPL_MODE.input                = {0, 1}
    RADAR_SPL_MODE.output               = {0, 1}
    RADAR_SPL_MODE.parameter_name       = "RADAR_SPL_MODE"

end





--[[
BASE_SENSOR_RADALT:5424.042480\
BASE_SENSOR_NOSE_GEAR_UP:1.000000\
BASE_SENSOR_AOS:0.000000\
BASE_SENSOR_STICK_PITCH_NORMED:0.044524\
BASE_SENSOR_BAROALT:6174.404297\
BASE_SENSOR_AOA:0.038323\
BASE_SENSOR_IAS:188.135193\
BASE_SENSOR_VERTICAL_SPEED:0.000000\
BASE_SENSOR_TAS:256.944458\
BASE_SENSOR_FLAPS_POS:0.000000\
BASE_SENSOR_HELI_CORRECTION:0.000000\
BASE_SENSOR_VERTICAL_ACCEL:1.000000\
BASE_SENSOR_LEFT_THROTTLE_RAW_CONTROL:0.000000\
BASE_SENSOR_MACH:0.812169\
BASE_SENSOR_LEFT_GEAR_UP:1.000000\
BASE_SENSOR_HORIZONTAL_ACCEL:0.000000\
EJECTION_BLOCKED_0:0.000000\
BASE_SENSOR_LATERAL_ACCEL:0.000000\
BASE_SENSOR_ROLL_RATE:0.000000\
BASE_SENSOR_YAW_RATE:0.000000\
BASE_SENSOR_PROPELLER_RPM:0.000000\
BASE_SENSOR_PITCH_RATE:0.000000\
BASE_SENSOR_LEFT_ENGINE_TEMP_BEFORE_TURBINE:320.000000\
BASE_SENSOR_LEFT_ENGINE_FUEL_CONSUPMTION:0.000000\
BASE_SENSOR_LEFT_THROTTLE_POS:0.000000\
BASE_SENSOR_WOW_NOSE_GEAR:0.000000\
BASE_SENSOR_ROLL:-0.000000\
BASE_SENSOR_MAG_HEADING:3.773644\
BASE_SENSOR_LEFT_GEAR_DOWN:0.000000\
BASE_SENSOR_HEADING:2.395708\
BASE_SENSOR_FUEL_TOTAL:6580.000000\
BASE_SENSOR_SPEED_BRAKE_POS:0.000000\
BASE_SENSOR_GEAR_HANDLE:0.000000\
BASE_SENSOR_NOSE_GEAR_DOWN:0.000000\
EJECTION_INITIATED_0:-1.000000\
BASE_SENSOR_RIGHT_ENGINE_FAN_RPM:70.000008\
BASE_SENSOR_WOW_LEFT_GEAR:0.000000\
BASE_SENSOR_WOW_RIGHT_GEAR:0.000000\
BASE_SENSOR_RIGHT_GEAR_DOWN:0.000000\
BASE_SENSOR_RIGHT_GEAR_UP:1.000000\
BASE_SENSOR_ALTIMETER_ATMO_PRESSURE_HG:0.000000\
BASE_SENSOR_STICK_ROLL_POS:4.452443\
BASE_SENSOR_STICK_PITCH_POS:0.000000\
BASE_SENSOR_RIGHT_ENGINE_RPM:70.000008\
BASE_SENSOR_RUDDER_POS:0.000000\
BASE_SENSOR_HELI_COLLECTIVE:0.000000\
BASE_SENSOR_CANOPY_POS:0.000000\
BASE_SENSOR_RIGHT_ENGINE_TEMP_BEFORE_TURBINE:320.000000\
BASE_SENSOR_RIGHT_ENGINE_FUEL_CONSUMPTION:0.000000\
BASE_SENSOR_CANOPY_STATE:0.000000\
BASE_SENSOR_FLAPS_RETRACTED:1.000000\
BASE_SENSOR_STICK_ROLL_NORMED:0.000000\
BASE_SENSOR_RUDDER_NORMED:0.000000\
BASE_SENSOR_PROPELLER_PITCH:0.000000\
BASE_SENSOR_RELATIVE_TORQUE:0.000000\
BASE_SENSOR_PROPELLER_TILT:0.000000\
BASE_SENSOR_LEFT_ENGINE_RPM:70.000008\
BASE_SENSOR_LEFT_ENGINE_FAN_RPM:70.000008\
BASE_SENSOR_RIGHT_THROTTLE_POS:0.000000\
BASE_SENSOR_RIGHT_THROTTLE_RAW_CONTROL:0.000000\

]]
need_to_be_closed  = true -- close lua state after initialization

